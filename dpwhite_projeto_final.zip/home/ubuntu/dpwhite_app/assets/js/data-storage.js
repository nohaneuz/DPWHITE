/**
 * Módulo de armazenamento e persistência de dados - DP White VH Seguros
 * Gerencia o armazenamento e recuperação de dados entre páginas
 */

// Objeto para gerenciar o armazenamento de dados
const DataStorage = {
  // Salva dados no localStorage
  salvar: function(chave, dados) {
    if (typeof dados === 'object') {
      localStorage.setItem(chave, JSON.stringify(dados));
    } else {
      localStorage.setItem(chave, dados);
    }
  },
  
  // Recupera dados do localStorage
  recuperar: function(chave) {
    const dados = localStorage.getItem(chave);
    if (!dados) return null;
    
    try {
      return JSON.parse(dados);
    } catch (e) {
      return dados;
    }
  },
  
  // Remove dados do localStorage
  remover: function(chave) {
    localStorage.removeItem(chave);
  },
  
  // Limpa todos os dados do localStorage exceto os dados do corretor
  limparDadosFormulario: function() {
    // Mantém apenas os dados do corretor
    const corretor = localStorage.getItem('corretor');
    
    // Limpa o localStorage
    localStorage.clear();
    
    // Restaura os dados do corretor
    if (corretor) {
      localStorage.setItem('corretor', corretor);
    }
  },
  
  // Coleta todos os dados armazenados no localStorage
  coletarTodosDados: function() {
    // Obtém o tipo de plano
    const tipoPlano = this.recuperar('tipoPlano');
    
    // Dados comuns a todos os tipos de plano
    const dadosComuns = {
      tipoPlano: tipoPlano,
      corretor: this.recuperar('corretor') || {},
      modalidade: this.recuperar('modalidade'),
      operadora: this.recuperar('operadora') || {}
    };
    
    // Dados específicos para cada tipo de plano
    if (tipoPlano === 'pme') {
      // Dados para plano PME
      return {
        ...dadosComuns,
        empresa: this.recuperar('empresa') || {},
        endereco: this.recuperar('endereco') || {},
        contrato: this.recuperar('contrato') || {}
      };
    } else {
      // Dados para plano Individual/Adesão
      return {
        ...dadosComuns,
        subtipoPlano: this.recuperar('subtipoPlano'),
        plano: this.recuperar('plano') || {},
        acomodacao: this.recuperar('acomodacao'),
        dadosPlano: this.recuperar('dadosPlano') || {},
        coparticipacao: this.recuperar('coparticipacao'),
        titular: this.recuperar('titular') || {},
        contato: this.recuperar('contato') || {},
        endereco: this.recuperar('endereco') || {}
      };
    }
  }
};

// Objeto para gerenciar a navegação entre páginas
const Navigation = {
  // Inicializa a navegação
  init: function() {
    this.setupNavigationButtons();
    this.setupOptionCards();
    this.setupFormValidation();
    this.preencherFormularios();
  },
  
  // Configura os botões de navegação
  setupNavigationButtons: function() {
    document.querySelectorAll('[data-navigate]').forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Verifica se o botão requer validação
        if (this.hasAttribute('data-validate') && this.getAttribute('data-validate') === 'true') {
          // Valida o formulário
          const form = document.querySelector('form');
          if (form && !form.checkValidity()) {
            form.reportValidity();
            return;
          }
          
          // Salva os dados do formulário
          Navigation.salvarDadosFormulario();
        }
        
        // Navega para a página especificada
        const targetPage = this.getAttribute('data-navigate');
        
        // Se for o botão "Anterior", verifica o fluxo condicional
        if (targetPage === 'anterior') {
          Navigation.navegarParaPaginaAnterior();
        } else {
          window.location.href = targetPage;
        }
      });
    });
  },
  
  // Configura os cards de opções
  setupOptionCards: function() {
    document.querySelectorAll('.option-card, .operadora-card').forEach(card => {
      card.addEventListener('click', function() {
        // Remove a classe 'selected' de todos os cards do mesmo grupo
        const parentElement = this.parentElement;
        parentElement.querySelectorAll('.option-card, .operadora-card').forEach(c => {
          c.classList.remove('selected');
        });
        
        // Adiciona a classe 'selected' ao card clicado
        this.classList.add('selected');
        
        // Habilita o botão de continuar se houver um com o atributo data-requires-selection
        const continueButton = document.querySelector('button[data-requires-selection="true"]');
        if (continueButton) {
          continueButton.disabled = false;
        }
        
        // Salva a seleção no localStorage
        Navigation.salvarSelecaoCard(this);
      });
    });
  },
  
  // Configura a validação de formulários
  setupFormValidation: function() {
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Valida o formulário
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        
        // Salva os dados do formulário
        Navigation.salvarDadosFormulario();
        
        // Navega para a próxima página
        const nextPage = form.getAttribute('data-next-page');
        if (nextPage) {
          window.location.href = nextPage;
        }
      });
    }
  },
  
  // Salva a seleção de um card no localStorage
  salvarSelecaoCard: function(card) {
    // Identifica o tipo de card e salva os dados correspondentes
    if (card.classList.contains('operadora-card')) {
      // Salva a operadora selecionada
      const operadora = {
        codigo: card.getAttribute('data-code'),
        nome: card.getAttribute('data-name'),
        imagem: card.querySelector('img')?.src || ''
      };
      DataStorage.salvar('operadora', operadora);
    } else if (window.location.pathname.includes('tipo-plano.html')) {
      // Salva o subtipo de plano selecionado
      const subtipoPlano = card.querySelector('.option-title').textContent.toLowerCase().includes('individual') ? 'individual' : 'adesao';
      DataStorage.salvar('subtipoPlano', subtipoPlano);
    } else if (window.location.pathname.includes('modalidade.html')) {
      // Salva a modalidade selecionada
      const modalidade = card.querySelector('.option-title').textContent.toLowerCase();
      DataStorage.salvar('modalidade', modalidade.includes('saúde') && modalidade.includes('odonto') ? 'saude_odonto' : 
                        modalidade.includes('saúde') ? 'saude' : 'odonto');
    } else if (window.location.pathname.includes('acomodacao.html')) {
      // Salva a acomodação selecionada
      const acomodacao = card.querySelector('.option-title').textContent.toLowerCase();
      DataStorage.salvar('acomodacao', acomodacao);
    } else if (window.location.pathname.includes('coparticipacao.html')) {
      // Salva a coparticipação selecionada
      const coparticipacao = card.querySelector('.option-title').textContent.toLowerCase();
      DataStorage.salvar('coparticipacao', coparticipacao.includes('completa') ? 'completa' : 
                        coparticipacao.includes('parcial') ? 'parcial' : 'nao');
    } else if (window.location.pathname.includes('index.html')) {
      // Salva o tipo de plano selecionado
      const tipoPlano = card.querySelector('.option-title').textContent.toLowerCase().includes('pme') ? 'pme' : 'individual';
      DataStorage.salvar('tipoPlano', tipoPlano);
    }
  },
  
  // Salva os dados do formulário no localStorage
  salvarDadosFormulario: function() {
    const form = document.querySelector('form');
    if (!form) return;
    
    // Identifica a página atual e salva os dados correspondentes
    if (window.location.pathname.includes('corretor.html')) {
      // Salva os dados do corretor
      const corretor = {
        cpf: document.getElementById('cpf-cnpj').value,
        nome: document.getElementById('nome-completo').value,
        email: document.getElementById('email').value,
        whatsapp: document.getElementById('whatsapp').value,
        supervisor: document.getElementById('supervisor').value
      };
      DataStorage.salvar('corretor', corretor);
    } else if (window.location.pathname.includes('empresa.html')) {
      // Salva os dados da empresa
      const empresa = {
        cnpj: document.getElementById('cnpj').value,
        razaoSocial: document.getElementById('razao-social').value,
        mei: document.querySelector('input[name="mei"]:checked')?.value || 'nao'
      };
      DataStorage.salvar('empresa', empresa);
    } else if (window.location.pathname.includes('endereco.html')) {
      // Salva os dados de endereço
      const endereco = {
        cep: document.getElementById('cep').value,
        logradouro: document.getElementById('logradouro').value,
        numero: document.getElementById('numero').value,
        complemento: document.getElementById('complemento').value,
        bairro: document.getElementById('bairro').value,
        cidade: document.getElementById('cidade').value,
        uf: document.getElementById('uf').value
      };
      DataStorage.salvar('endereco', endereco);
    } else if (window.location.pathname.includes('plano.html')) {
      // Salva os dados do plano
      const plano = {
        nome: document.getElementById('nome-plano').value,
        vigencia: document.getElementById('vigencia').value
      };
      DataStorage.salvar('plano', plano);
    } else if (window.location.pathname.includes('dados-plano.html')) {
      // Salva os dados do plano
      const dadosPlano = {
        valor: document.getElementById('valor-plano').value
      };
      DataStorage.salvar('dadosPlano', dadosPlano);
    } else if (window.location.pathname.includes('titular.html')) {
      // Salva os dados do titular
      const titular = {
        cpf: document.getElementById('cpf-titular').value,
        nome: document.getElementById('nome-titular').value,
        dataNascimento: document.getElementById('data-nascimento').value,
        rg: document.getElementById('rg').value
      };
      DataStorage.salvar('titular', titular);
    } else if (window.location.pathname.includes('contato.html')) {
      // Salva os dados de contato
      const contato = {
        email: document.getElementById('email').value,
        telefone: document.getElementById('telefone').value
      };
      DataStorage.salvar('contato', contato);
    } else if (window.location.pathname.includes('detalhes-contrato.html')) {
      // Salva os dados do contrato
      const contrato = {
        tipoContratacao: document.querySelector('input[name="tipo-contratacao"]:checked')?.value || '',
        coparticipacao: document.querySelector('input[name="coparticipacao"]:checked')?.value || '',
        valor: document.getElementById('valor-contrato').value,
        dataVigencia: document.getElementById('data-vigencia').value
      };
      DataStorage.salvar('contrato', contrato);
    }
  },
  
  // Preenche os formulários com dados salvos
  preencherFormularios: function() {
    // Identifica a página atual e preenche os dados correspondentes
    if (window.location.pathname.includes('corretor.html')) {
      // Preenche os dados do corretor
      const corretor = DataStorage.recuperar('corretor');
      if (corretor) {
        document.getElementById('cpf-cnpj').value = corretor.cpf || '';
        document.getElementById('nome-completo').value = corretor.nome || '';
        document.getElementById('email').value = corretor.email || '';
        document.getElementById('whatsapp').value = corretor.whatsapp || '';
        document.getElementById('supervisor').value = corretor.supervisor || '';
      }
    } else if (window.location.pathname.includes('empresa.html')) {
      // Preenche os dados da empresa
      const empresa = DataStorage.recuperar('empresa');
      if (empresa) {
        document.getElementById('cnpj').value = empresa.cnpj || '';
        document.getElementById('razao-social').value = empresa.razaoSocial || '';
        if (empresa.mei) {
          document.querySelector(`input[name="mei"][value="${empresa.mei}"]`).checked = true;
        }
      }
    } else if (window.location.pathname.includes('endereco.html')) {
      // Preenche os dados de endereço
      const endereco = DataStorage.recuperar('endereco');
      if (endereco) {
        document.getElementById('cep').value = endereco.cep || '';
        document.getElementById('logradouro').value = endereco.logradouro || '';
        document.getElementById('numero').value = endereco.numero || '';
        document.getElementById('complemento').value = endereco.complemento || '';
        document.getElementById('bairro').value = endereco.bairro || '';
        document.getElementById('cidade').value = endereco.cidade || '';
        document.getElementById('uf').value = endereco.uf || '';
      }
    } else if (window.location.pathname.includes('plano.html')) {
      // Preenche os dados do plano
      const plano = DataStorage.recuperar('plano');
      if (plano) {
        document.getElementById('nome-plano').value = plano.nome || '';
        document.getElementById('vigencia').value = plano.vigencia || '';
      }
    } else if (window.location.pathname.includes('dados-plano.html')) {
      // Preenche os dados do plano
      const dadosPlano = DataStorage.recuperar('dadosPlano');
      if (dadosPlano) {
        document.getElementById('valor-plano').value = dadosPlano.valor || '';
      }
    } else if (window.location.pathname.includes('titular.html')) {
      // Preenche os dados do titular
      const titular = DataStorage.recuperar('titular');
      if (titular) {
        document.getElementById('cpf-titular').value = titular.cpf || '';
        document.getElementById('nome-titular').value = titular.nome || '';
        document.getElementById('data-nascimento').value = titular.dataNascimento || '';
        document.getElementById('rg').value = titular.rg || '';
      }
    } else if (window.location.pathname.includes('contato.html')) {
      // Preenche os dados de contato
      const contato = DataStorage.recuperar('contato');
      if (contato) {
        document.getElementById('email').value = contato.email || '';
        document.getElementById('telefone').value = contato.telefone || '';
      }
    } else if (window.location.pathname.includes('detalhes-contrato.html')) {
      // Preenche os dados do contrato
      const contrato = DataStorage.recuperar('contrato');
      if (contrato) {
        if (contrato.tipoContratacao) {
          document.querySelector(`input[name="tipo-contratacao"][value="${contrato.tipoContratacao}"]`).checked = true;
        }
        if (contrato.coparticipacao) {
          document.querySelector(`input[name="coparticipacao"][value="${contrato.coparticipacao}"]`).checked = true;
        }
        document.getElementById('valor-contrato').value = contrato.valor || '';
        document.getElementById('data-vigencia').value = contrato.dataVigencia || '';
      }
    }
    
    // Verifica se há cards selecionáveis na página e marca o selecionado
    this.marcarCardSelecionado();
  },
  
  // Marca o card selecionado com base nos dados salvos
  marcarCardSelecionado: function() {
    if (window.location.pathname.includes('tipo-plano.html')) {
      // Marca o subtipo de plano selecionado
      const subtipoPlano = DataStorage.recuperar('subtipoPlano');
      if (subtipoPlano) {
        const cards = document.querySelectorAll('.option-card');
        const index = subtipoPlano === 'individual' ? 0 : 1;
        if (cards[index]) {
          cards[index].classList.add('selected');
          const continueButton = document.querySelector('button[data-requires-selection="true"]');
          if (continueButton) {
            continueButton.disabled = false;
          }
        }
      }
    } else if (window.location.pathname.includes('modalidade.html')) {
      // Marca a modalidade selecionada
      const modalidade = DataStorage.recuperar('modalidade');
      if (modalidade) {
        const cards = document.querySelectorAll('.option-card');
        const index = modalidade === 'saude' ? 0 : modalidade === 'odonto' ? 1 : 2;
        if (cards[index]) {
          cards[index].classList.add('selected');
          const continueButton = document.querySelector('button[data-requires-selection="true"]');
          if (continueButton) {
            continueButton.disabled = false;
          }
        }
      }
    } else if (window.location.pathname.includes('operadora.html')) {
      // Marca a operadora selecionada
      const operadora = DataStorage.recuperar('operadora');
      if (operadora) {
        const cards = document.querySelectorAll('.operadora-card');
        cards.forEach(card => {
          if (card.getAttribute('data-code') === operadora.codigo) {
            card.classList.add('selected');
            const continueButton = document.querySelector('button[data-requires-selection="true"]');
            if (continueButton) {
              continueButton.disabled = false;
            }
          }
        });
      }
    } else if (window.location.pathname.includes('acomodacao.html')) {
      // Marca a acomodação selecionada
      const acomodacao = DataStorage.recuperar('acomodacao');
      if (acomodacao) {
        const cards = document.querySelectorAll('.option-card');
        const index = acomodacao.includes('apartamento') ? 0 : 1;
        if (cards[index]) {
          cards[index].classList.add('selected');
          const continueButton = document.querySelector('button[data-requires-selection="true"]');
          if (continueButton) {
            continueButton.disabled = false;
          }
        }
      }
    } else if (window.location.pathname.includes('coparticipacao.html')) {
      // Marca a coparticipação selecionada
      const coparticipacao = DataStorage.recuperar('coparticipacao');
      if (coparticipacao) {
        const cards = document.querySelectorAll('.option-card');
        const index = coparticipacao === 'completa' ? 0 : coparticipacao === 'parcial' ? 1 : 2;
        if (cards[index]) {
          cards[index].classList.add('selected');
          const continueButton = document.querySelector('button[data-requires-selection="true"]');
          if (continueButton) {
            continueButton.disabled = false;
          }
        }
      }
    }
  },
  
  // Navega para a página anterior respeitando o fluxo condicional
  navegarParaPaginaAnterior: function() {
    const tipoPlano = DataStorage.recuperar('tipoPlano');
    
    // Determina a página anterior baseado no fluxo
    if (window.location.pathname.includes('modalidade.html')) {
      if (tipoPlano === 'pme') {
        window.location.href = 'corretor.html';
      } else {
        window.location.href = 'tipo-plano.html';
      }
    } else if (window.location.pathname.includes('tipo-plano.html')) {
      window.location.href = 'corretor.html';
    } else if (window.location.pathname.includes('operadora.html')) {
      if (tipoPlano === 'pme') {
        window.location.href = 'modalidade.html';
      } else {
        window.location.href = 'modalidade.html';
      }
    } else if (window.location.pathname.includes('empresa.html')) {
      window.location.href = 'operadora.html';
    } else if (window.location.pathname.includes('endereco.html')) {
      if (tipoPlano === 'pme') {
        window.location.href = 'empresa.html';
      } else {
        window.location.href = 'contato.html';
      }
    } else if (window.location.pathname.includes('detalhes-contrato.html')) {
      window.location.href = 'endereco.html';
    } else if (window.location.pathname.includes('plano.html')) {
      window.location.href = 'operadora.html';
    } else if (window.location.pathname.includes('acomodacao.html')) {
      window.location.href = 'plano.html';
    } else if (window.location.pathname.includes('dados-plano.html')) {
      window.location.href = 'acomodacao.html';
    } else if (window.location.pathname.includes('coparticipacao.html')) {
      window.location.href = 'dados-plano.html';
    } else if (window.location.pathname.includes('titular.html')) {
      window.location.href = 'coparticipacao.html';
    } else if (window.location.pathname.includes('contato.html')) {
      window.location.href = 'titular.html';
    } else if (window.location.pathname.includes('resumo.html')) {
      if (tipoPlano === 'pme') {
        window.location.href = 'detalhes-contrato.html';
      } else {
        window.location.href = 'endereco.html';
      }
    } else {
      // Página não identificada, volta para a página inicial
      window.location.href = 'index.html';
    }
  }
};

// Inicializa o módulo quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
  Navigation.init();
});

// Exporta os objetos para uso em outros arquivos
window.DataStorage = DataStorage;
window.Navigation = Navigation;
