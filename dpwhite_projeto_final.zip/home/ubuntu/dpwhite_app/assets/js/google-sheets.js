/**
 * Google Sheets Integration Module
 * DP White VH Seguros
 * 
 * Este módulo gerencia a integração com o Google Sheets para armazenamento
 * de propostas PME e PF/Adesão em planilhas separadas.
 */

// URL da Web App do Google Apps Script (será substituída pela URL real fornecida pelo usuário)
const GOOGLE_SCRIPT_URL = "URL_A_SER_SUBSTITUIDA";

/**
 * Envia os dados da proposta para o Google Sheets
 * @param {Object} propostaData - Dados da proposta a serem enviados
 * @returns {Promise} - Promise com o resultado da operação
 */
async function enviarPropostaParaGoogleSheets(propostaData) {
  try {
    // Exibe mensagem de carregamento
    window.cepUtils.mostrarMensagemCarregamento('Enviando proposta...');
    
    // Prepara os dados para envio
    const dadosParaEnvio = {
      tipoProposta: localStorage.getItem('tipoProposta') || 'PF',
      cpfCorretor: localStorage.getItem('cpfCorretor') || '',
      nomeCorretor: localStorage.getItem('nomeCorretor') || '',
      emailCorretor: localStorage.getItem('emailCorretor') || '',
      telefoneCorretor: localStorage.getItem('telefoneCorretor') || '',
      modalidade: localStorage.getItem('modalidade') || '',
      operadora: localStorage.getItem('operadora') || '',
      nomePlano: localStorage.getItem('nomePlano') || '',
      vigencia: localStorage.getItem('vigencia') || '',
      acomodacao: localStorage.getItem('acomodacao') || '',
      valorPlano: localStorage.getItem('valorPlano') || '',
      coparticipacao: localStorage.getItem('coparticipacao') || '',
      dadosCliente: JSON.stringify({
        nome: localStorage.getItem('nomeCliente') || '',
        cpf: localStorage.getItem('cpfCliente') || '',
        email: localStorage.getItem('emailCliente') || '',
        telefone: localStorage.getItem('telefoneCliente') || '',
        endereco: {
          cep: localStorage.getItem('cep') || '',
          logradouro: localStorage.getItem('logradouro') || '',
          numero: localStorage.getItem('numero') || '',
          complemento: localStorage.getItem('complemento') || '',
          bairro: localStorage.getItem('bairro') || '',
          cidade: localStorage.getItem('cidade') || '',
          uf: localStorage.getItem('uf') || ''
        }
      })
    };
    
    // Verifica se a URL do Google Script está configurada
    if (GOOGLE_SCRIPT_URL === "URL_A_SER_SUBSTITUIDA") {
      console.warn("URL do Google Script não configurada. Os dados serão armazenados apenas localmente.");
      
      // Simula um atraso para dar feedback ao usuário
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Oculta mensagem de carregamento
      window.cepUtils.ocultarMensagemCarregamento();
      
      // Exibe mensagem de sucesso simulado
      window.cepUtils.mostrarMensagem('Proposta salva localmente com sucesso! (Integração com Google Sheets pendente)', 'info');
      
      return {
        success: true,
        message: 'Dados salvos localmente. Integração com Google Sheets pendente.'
      };
    }
    
    // Envia os dados para o Google Script
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',
      cache: 'no-cache',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(dadosParaEnvio)
    });
    
    // Oculta mensagem de carregamento
    window.cepUtils.ocultarMensagemCarregamento();
    
    // Como estamos usando 'no-cors', não podemos ler a resposta
    // Assumimos que o envio foi bem-sucedido se não houver erro
    window.cepUtils.mostrarMensagem('Proposta enviada com sucesso!', 'success');
    
    return {
      success: true,
      message: 'Dados enviados com sucesso para o Google Sheets!'
    };
  } catch (error) {
    // Oculta mensagem de carregamento
    window.cepUtils.ocultarMensagemCarregamento();
    
    // Exibe mensagem de erro
    window.cepUtils.mostrarMensagem(`Erro ao enviar proposta: ${error.message}`, 'error');
    
    // Registra o erro no console
    console.error('Erro ao enviar proposta:', error);
    
    return {
      success: false,
      message: `Erro ao enviar dados: ${error.message}`
    };
  }
}

// Exporta as funções para uso em outros arquivos
window.googleSheetsIntegration = {
  enviarPropostaParaGoogleSheets
};
