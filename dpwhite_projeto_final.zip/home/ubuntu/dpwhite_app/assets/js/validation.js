/**
 * Validação de CPF e integração com base de corretores
 * DP White VH Seguros
 */

// Base de dados de corretores (simulada)
const corretoresDB = [
  {
    cpf: '352.896.578-94',
    nome: 'João da Silva',
    email: 'joao.silva@dpwhite.com.br',
    telefone: '(11) 98765-4321'
  },
  {
    cpf: '123.456.789-00',
    nome: 'Maria Oliveira',
    email: 'maria.oliveira@dpwhite.com.br',
    telefone: '(11) 91234-5678'
  },
  {
    cpf: '987.654.321-00',
    nome: 'Carlos Santos',
    email: 'carlos.santos@dpwhite.com.br',
    telefone: '(11) 99876-5432'
  }
];

/**
 * Valida um CPF
 * @param {string} cpf - CPF a ser validado
 * @returns {boolean} - Verdadeiro se o CPF for válido
 */
function validarCPF(cpf) {
  // Remove caracteres não numéricos
  cpf = cpf.replace(/\D/g, '');
  
  // Verifica se o CPF tem 11 dígitos
  if (cpf.length !== 11) {
    return false;
  }
  
  // Verifica se todos os dígitos são iguais
  if (/^(\d)\1+$/.test(cpf)) {
    return false;
  }
  
  // Validação do primeiro dígito verificador
  let soma = 0;
  for (let i = 0; i < 9; i++) {
    soma += parseInt(cpf.charAt(i)) * (10 - i);
  }
  
  let resto = soma % 11;
  let digitoVerificador1 = resto < 2 ? 0 : 11 - resto;
  
  if (digitoVerificador1 !== parseInt(cpf.charAt(9))) {
    return false;
  }
  
  // Validação do segundo dígito verificador
  soma = 0;
  for (let i = 0; i < 10; i++) {
    soma += parseInt(cpf.charAt(i)) * (11 - i);
  }
  
  resto = soma % 11;
  let digitoVerificador2 = resto < 2 ? 0 : 11 - resto;
  
  if (digitoVerificador2 !== parseInt(cpf.charAt(10))) {
    return false;
  }
  
  return true;
}

/**
 * Busca um corretor pelo CPF
 * @param {string} cpf - CPF do corretor
 * @returns {Object|null} - Dados do corretor ou null se não encontrado
 */
function buscarCorretorPorCPF(cpf) {
  // Remove caracteres não numéricos para comparação
  const cpfLimpo = cpf.replace(/\D/g, '');
  
  // Busca o corretor na base de dados
  const corretor = corretoresDB.find(c => c.cpf.replace(/\D/g, '') === cpfLimpo);
  
  return corretor || null;
}

/**
 * Formata um CPF com pontuação
 * @param {string} cpf - CPF a ser formatado
 * @returns {string} - CPF formatado
 */
function formatarCPF(cpf) {
  // Remove caracteres não numéricos
  cpf = cpf.replace(/\D/g, '');
  
  // Formata o CPF: 000.000.000-00
  return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

/**
 * Adiciona um novo corretor à base de dados
 * @param {Object} corretor - Dados do corretor
 * @returns {boolean} - Verdadeiro se o corretor foi adicionado com sucesso
 */
function adicionarCorretor(corretor) {
  // Verifica se o CPF é válido
  if (!validarCPF(corretor.cpf)) {
    return false;
  }
  
  // Verifica se o corretor já existe
  if (buscarCorretorPorCPF(corretor.cpf)) {
    return false;
  }
  
  // Formata o CPF
  corretor.cpf = formatarCPF(corretor.cpf);
  
  // Adiciona o corretor à base de dados
  corretoresDB.push(corretor);
  
  return true;
}

// Exporta as funções para uso em outros arquivos
window.corretorValidator = {
  validarCPF,
  buscarCorretorPorCPF,
  formatarCPF,
  adicionarCorretor
};
