// Script para garantir que os filtros avançados expandam corretamente
document.addEventListener('DOMContentLoaded', function() {
  // Elementos DOM
  const toggleAdvancedSearch = document.getElementById('toggleAdvancedSearch');
  const advancedSearchBody = document.getElementById('advancedSearchBody');
  
  if (toggleAdvancedSearch && advancedSearchBody) {
    // Garantir que o corpo dos filtros avançados comece fechado
    advancedSearchBody.style.display = 'none';
    
    // Adicionar evento de clique ao botão de toggle
    toggleAdvancedSearch.addEventListener('click', function() {
      // Alternar visibilidade do corpo dos filtros
      if (advancedSearchBody.style.display === 'none') {
        advancedSearchBody.style.display = 'block';
        toggleAdvancedSearch.textContent = '▲'; // Seta para cima quando aberto
        toggleAdvancedSearch.classList.add('active');
      } else {
        advancedSearchBody.style.display = 'none';
        toggleAdvancedSearch.textContent = '▼'; // Seta para baixo quando fechado
        toggleAdvancedSearch.classList.remove('active');
      }
    });
    
    console.log('Script de filtros avançados inicializado com sucesso');
  } else {
    console.error('Elementos de filtro avançado não encontrados no DOM');
  }
});
