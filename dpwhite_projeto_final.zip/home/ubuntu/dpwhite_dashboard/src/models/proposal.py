from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Proposal(db.Model):
    __tablename__ = 'proposals'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Proposal type and status
    proposal_type = db.Column(db.String(20), nullable=False)  # 'pme', 'adesao', 'individual', 'familiar'
    status = db.Column(db.String(20), nullable=False, default='nova')  # 'nova', 'pendente', 'enviada', 'declinada'
    
    # Client/Company information
    client_name = db.Column(db.String(100), nullable=False)
    client_document = db.Column(db.String(20), nullable=True)  # CPF or CNPJ
    client_email = db.Column(db.String(120), nullable=True)
    client_phone = db.Column(db.String(20), nullable=True)
    
    # Address information
    address_cep = db.Column(db.String(10), nullable=True)
    address_street = db.Column(db.String(100), nullable=True)
    address_number = db.Column(db.String(10), nullable=True)
    address_complement = db.Column(db.String(100), nullable=True)
    address_district = db.Column(db.String(100), nullable=True)
    address_city = db.Column(db.String(100), nullable=True)
    address_state = db.Column(db.String(2), nullable=True)
    
    # Plan information
    plan_name = db.Column(db.String(100), nullable=True)
    plan_operator = db.Column(db.String(100), nullable=True)
    plan_modality = db.Column(db.String(100), nullable=True)
    plan_value = db.Column(db.String(20), nullable=True)
    plan_coparticipation = db.Column(db.String(20), nullable=True)
    plan_accommodation = db.Column(db.String(20), nullable=True)
    plan_validity = db.Column(db.String(50), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with attachments
    attachments = db.relationship('Attachment', backref='proposal', lazy=True, cascade="all, delete-orphan")
    
    def to_dict(self):
        """Convert proposal to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'proposal_type': self.proposal_type,
            'status': self.status,
            'client_name': self.client_name,
            'client_document': self.client_document,
            'client_email': self.client_email,
            'client_phone': self.client_phone,
            'address_cep': self.address_cep,
            'address_street': self.address_street,
            'address_number': self.address_number,
            'address_complement': self.address_complement,
            'address_district': self.address_district,
            'address_city': self.address_city,
            'address_state': self.address_state,
            'plan_name': self.plan_name,
            'plan_operator': self.plan_operator,
            'plan_modality': self.plan_modality,
            'plan_value': self.plan_value,
            'plan_coparticipation': self.plan_coparticipation,
            'plan_accommodation': self.plan_accommodation,
            'plan_validity': self.plan_validity,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'attachments': [attachment.to_dict() for attachment in self.attachments]
        }


class Attachment(db.Model):
    __tablename__ = 'attachments'
    
    id = db.Column(db.Integer, primary_key=True)
    proposal_id = db.Column(db.Integer, db.ForeignKey('proposals.id'), nullable=False)
    
    filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    file_type = db.Column(db.String(50), nullable=True)
    file_size = db.Column(db.Integer, nullable=True)  # Size in bytes
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert attachment to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'proposal_id': self.proposal_id,
            'filename': self.filename,
            'file_path': self.file_path,
            'file_type': self.file_type,
            'file_size': self.file_size,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
